import pygame, sys, random, time  # usual import statements

pygame.init()  # initiates pygame
pygame.mixer.init() # initiates sound
clock = pygame.time.Clock()  # allows us to use FPS

#Sound Effects
bullet = pygame.mixer.Sound("Bullet.mp3")
select = pygame.mixer.Sound("Select.mp3")
gmsfx = pygame.mixer.Sound("GameOver.mp3")
vsfx = pygame.mixer.Sound("Victory.mp3")
explosion = pygame.mixer.Sound("Explode.mp3")

# Game Window
w = 600
h = 450
windowSize = (w, h)
screen = pygame.display.set_mode(windowSize)

# Colour
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (2, 133, 59)
BLUE = (136,216,192)
YELLOW = (255,255,0)
WHITE = (255,255,255)
ORANGE = (253, 101, 59)

# Intro Screen
def intro():
  intro = True
  while intro:
    screen.fill(BLUE)
    font1 = pygame.font.SysFont("Myriad Pro", 75)
    
    title=pygame.image.load('Logo.png')
    titlesize = pygame.transform.scale(title,(225,125)) 
    screen.blit(titlesize, (200, 20))  # Puts title screen in the top centre of the page
    

    startButton = font1.render("Start", 1, BLACK, GREEN)
    startButton_size = startButton.get_size()
    start = screen.blit(startButton, (w / 2 - startButton_size[0] / 2, 160)) # Makes a start button

    exitButton = font1.render("Exit", 1, RED, WHITE)
    exitButton_size = exitButton.get_size()
    exit = screen.blit(exitButton, (w / 2 - exitButton_size[0] / 2, 255)) # Makes an exit button

    instructionsButton = font1.render("Instructions", 1, BLACK,GREEN)
    instructionsButton_size = instructionsButton.get_size()
    instructions = screen.blit(instructionsButton, (w / 2 - instructionsButton_size[0] / 2, 350)) # Makes an instruction button

    mousePosition = pygame.mouse.get_pos()
    #Gets the mouse position
    x, y = mousePosition

    pygame.display.update()
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        sys.exit()  # If person pressed "x" it quits the game
      if event.type == pygame.MOUSEBUTTONDOWN:
        if start.collidepoint(mousePosition):  # If the user clicks on start, it starts the game
          select.play()
          intro = False
          gameLoop()
        if exit.collidepoint(mousePosition):  # If the user clicks on exit
          select.play()
          sys.exit("Thanks for playing!")  # We exit the program via the sys.exit() function.
        if instructions.collidepoint(mousePosition):  # If the user clicks on the instructions button
          select.play()
          intro = False
          Instructions()  # When the user presses the instructions button, intro becomes false, and it enters the Intructions menu
  pygame.display.update()

# Instructions
def Instructions():
  instructions = True
  while instructions:
    screen.fill(WHITE)
    font1 = pygame.font.SysFont("Myriad Pro", 50)
    font2 = pygame.font.SysFont("Myriad Pro", 100)
    font3 = pygame.font.SysFont("Myriad Pro", 30)
    instructions = font2.render("Instructions", 1, BLACK)
    inSize = instructions.get_size()
    instructions2 = font3.render("Dodge the projectiles", 1, RED)
    instructions3 = font3.render("Don't touch the stage hazards", 1, RED)
    instructions4 = font3.render("Defeat the boss to win! (It has 50 health)", 1, RED)
    instructions5 = font2.render("Controls", 1, BLACK)
    conSize = instructions5.get_size()
    instructions6 = font3.render("Use arrow keys to move", 1, RED)
    instructions7 = font3.render("Space to shoot, and shift to dash back", 1, RED)
    instructions8 = font3.render("TIP: You can shoot the boss up close, then", 1, RED)
    instructions9 = font3.render("dash back quickly for big bursts of damage!", 1, RED)
    instructions10 = font1.render("Click anywhere to go back", 1, BLACK)
    backSize = instructions10.get_size()

    #Places the instructions on the instruction page
    screen.blit(instructions, (w/2 - inSize[0]/2, 0))
    screen.blit(instructions2, (100, 80))
    screen.blit(instructions3, (100, 115))
    screen.blit(instructions4, (100, 150))
    screen.blit(instructions5, (w/2 - conSize[0]/2, h/2 - 35))
    screen.blit(instructions6, (100, h/2 +30))
    screen.blit(instructions7, (100, h/2 +65))
    screen.blit(instructions8, (100, h/2 +100))
    screen.blit(instructions9, (100, h/2 +135))
    screen.blit(instructions10, (w/2 - backSize[0]/2, 400))

    mousePosition = pygame.mouse.get_pos()
    #Gets the mouse position
    x, y = mousePosition

    pygame.display.update()
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        sys.exit()  # If person pressed "x" it quits the game
      if event.type == pygame.MOUSEBUTTONDOWN:  # As soon as the user clicks, it goes back to the menu
        select.play()
        instructions = False
        intro()

# Score Display
def score(count):
  font = pygame.font.SysFont(None, 25)
  score = font.render("Score: " + str(count), 1, (
      WHITE)) 
  screen.blit(score, (0, 0))  # Prints score in the top left of the function

# Victory Text
def Victory():
  myriadProFont = pygame.font.SysFont("Myriad Pro", 112)
  Victory = myriadProFont.render("YOU WIN!", 1, GREEN)
  bullet.stop()
  vsfx.play()
  vsize = Victory.get_size()
  x1 = w / 2 - vsize[0] / 2
  y1 = h / 2 - vsize[1] / 2
  screen.blit(Victory, (x1, y1))
  pygame.display.update()
  time.sleep(2) #This leaves the text on screen for 2 seconds
  intro()
  
# Game Over Text
def GameOver():
  myriadProFont = pygame.font.SysFont("Myriad Pro", 112)
  gameOver = myriadProFont.render("GAME OVER", 1, RED)
  bullet.stop()
  gmsfx.play()
  gmsize = gameOver.get_size()
  x1 = w / 2 - gmsize[0] / 2
  y1 = h / 2 - gmsize[1] / 2
  screen.blit(gameOver, (x1, y1))
  pygame.display.update()
  time.sleep(2) #This leaves the text on screen for 2 seconds
  intro()

def gameLoop():
  # Player Character Coordinates
  rectW = 50
  rectH = 50
  x = w / 2 - rectW / 2
  y = h - rectH

  #Boss Spawn Coordinates
  bossx = 250
  bossy = 20
  directionX = 1 #Direction the boss moves in

  #Player Projectile Coordinates
  projectStartx = x
  projectStarty = y
  projectWidth = 30
  projectHeight = 30
  projectSpeed = 10  #Speed of moving projectile

  #Enemy Projectile Coordinates
  eprojectStartx = bossx + 50
  eprojectStarty = bossy + 50
  eprojectWidth = 30
  eprojectHeight = 30
  eprojectSpeed = 5  #Speed of moving projectile
  
  # Generate Rectangles Function
  def generateRect(x1, y1, w1, h1, colour):
    return pygame.draw.rect(screen, colour, [x1, y1, w1, h1])

  #Healthbar Rectangle Coordinates
  healthx = 0
  healthy = 100
  healthWidth = 500
  healthHeight = 20
    
  # Hazard  Coordinates
  rectStartx =  -50
  rectStarty = random.randrange(0, w)
  rectWidth = 40
  rectHeight = 40
  rectSpeed = 5  # Speed of moving rectangle
  
  inPlay = True #Keeps the game running
  scoreCount = 0 #Keeps score

  while inPlay:
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
          sys.exit()  # If we press x on the screen it closes the game
        
    # Player Character Movement
    keys = pygame.key.get_pressed()  # As we hold keys, character moves
    if keys[pygame.K_UP]:
      y = y - 5
    if keys[pygame.K_LEFT]:
      x = x - 5
    if keys[pygame.K_RIGHT]:
      x = x + 5
    if keys[pygame.K_DOWN]:
      y = y + 5
    if keys[pygame.K_SPACE]:
      bullet.stop() #Sound effect
      bullet.play()
      if projectStarty < 1:  # Check to see when rectangle is off the screen
        projectStarty = y
        projectStartx = x
        #Projectile starts again at player position if space is pressed, and this makes sure only 1 projectile is on the screen at a time
    if keys[pygame.K_LSHIFT]:
      y = y + 20
      #Dash back
    screen.fill(BLACK) #Background
    
    #Projectile generation
    blueball = pygame.image.load('Blueball.png')
    bluesize = pygame.transform.scale(blueball,(projectWidth,projectHeight))
    projectile = screen.blit(bluesize, (projectStartx,projectStarty))
    projectStarty -= projectSpeed #Projectile speed
    
    #Enemy Projectile generation
    redball = pygame.image.load('Redball.png')
    redsize = pygame.transform.scale(redball,(eprojectWidth,eprojectHeight))
    eprojectile = screen.blit(redsize, (eprojectStartx,eprojectStarty))
    eprojectStarty += eprojectSpeed #Projectile speed
    if eprojectStarty > h: #Projectile starts again if offscreen
      eprojectStarty = bossy
      eprojectStartx = bossx
    
    #Character generation
    ship = pygame.image.load('Ship.png')
    shipsize = pygame.transform.scale(ship,(25,25))
    player = screen.blit(shipsize, (x,y))
    #Boundaries for the character
    if x > 500:
      x = x - 5
    if x < 0:
      x = x + 5
    if y > 400: #Different from other boundaries since the player can dash backwards, which is faster than normal movement speed
      y = y - 25
    if y < 0:
      y = y + 5
  
    #Boss generation
    galaga = pygame.image.load('Galaga.png')
    galagasize = pygame.transform.scale(galaga,(50,50))
    boss = screen.blit(galagasize, (bossx, bossy))

    #Boss health
    health = generateRect(healthy, healthx, healthWidth, healthHeight, GREEN) #Full health
    if healthWidth <= 375 and healthWidth >= 250:
      health = generateRect(healthy, healthx, healthWidth, healthHeight, YELLOW) #Moderate health
    if healthWidth <= 250 and healthWidth >= 125:
      health = generateRect(healthy, healthx, healthWidth, healthHeight, ORANGE) #Medium health
    if healthWidth <= 125 and healthWidth >= 10:
      health = generateRect(healthy, healthx, healthWidth, healthHeight, RED) #Low health
    if healthWidth <= 10: #Death
      health = generateRect(healthy, healthx, healthWidth, healthHeight, BLACK)
    
    #Boss movement and boundaries
    bossx += 5 * directionX
    if bossx > 500 or bossx < 0:
      directionX *= -1

    #Stage hazard movement
    blocks = generateRect(rectStarty, rectStartx, rectWidth, rectHeight, RED)
    rectStarty += rectSpeed 

    #Stage hazard regeneration
    if rectStarty > w or projectile.colliderect(blocks): #Checks if hazard is offscreen
      rectStarty = 0 - rectHeight 
      rectStartx = random.randrange(0, w) #Redraws hazard
      rectWidth += 0.2
      rectHeight += 0.2 #Hazards become larger
      rectSpeed += 0.5  # Speed also increases by a bit
      scoreCount += 50 #Score for avoiding or shooting hazards
      
      #Hazard collision
    if blocks.colliderect(player): 
      GameOver()

      #Projectile collision
    if projectile.colliderect(boss):
      bullet.stop() #Sound effect
      bullet.play()
      scoreCount += 100 #Score for hitting the boss
      projectStarty = -25 #Projectile disappears goes offscreen so the player can shoot again
      healthWidth -= 10 #Lowers healthbar

      #Counter collision
    if eprojectile.colliderect(projectile):
      explosion.stop() #Sound effect
      explosion.play()
      projectStarty = -25 #Projectile disappears
      eprojectStarty = bossy #Enemy projectile starts again
      eprojectStartx = bossx
      scoreCount += 10 #Score for countering a projectile
      
      #Enemy Projectile collision
    if eprojectile.colliderect(player):
      GameOver()

      #Boss collision
    if player.colliderect(boss):
      GameOver()

      #Win Condition
    if healthWidth == 0:
      Victory()

    #FPS and score
    score(scoreCount)
    pygame.display.update()
    clock.tick(60)

intro()
#Goes back to menu